from django.apps import AppConfig


class InventaireConfig(AppConfig):
    name = 'inventaire'
