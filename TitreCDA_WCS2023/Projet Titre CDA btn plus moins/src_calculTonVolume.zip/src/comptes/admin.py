from django.contrib import admin

from comptes.models import Client

admin.site.register(Client)

